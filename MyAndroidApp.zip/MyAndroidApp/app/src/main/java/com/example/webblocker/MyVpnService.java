package com.example.webblocker;

import android.net.VpnService;
import android.os.ParcelFileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;

public class MyVpnService extends VpnService {

    private ParcelFileDescriptor vpnInterface;

    @Override
    public int onStartCommand(android.content.Intent intent, int flags, int startId) {
        // Build and start the VPN interface
        Builder builder = new Builder();
        builder.setSession("WebBlockerVPN")
               .addAddress("10.0.0.2", 24)
               .addRoute("0.0.0.0", 0);
        vpnInterface = builder.establish();

        // Start the VPN processing in a new thread
        new Thread(this::runVpn).start();
        return START_STICKY;
    }

    // The main loop to read and process network packets
    private void runVpn() {
        try {
            FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
            FileOutputStream out = new FileOutputStream(vpnInterface.getFileDescriptor());
            ByteBuffer packet = ByteBuffer.allocate(32767);
            while (true) {
                int length = in.read(packet.array());
                if (length > 0) {
                    // Convert the packet data to a String (simplified demo)
                    String data = new String(Arrays.copyOfRange(packet.array(), 0, length));
                    // Check if the data (or destination) contains allowed websites\n                    if (!isAllowed(data)) {
                        // Block the packet by doing nothing (or you can add logging here)\n                        Arrays.fill(packet.array(), (byte) 0);
                        continue;
                    }
                    // Forward allowed packets
                    out.write(packet.array(), 0, length);
                }
            }
        } catch (Exception ignored) {
            // Handle exceptions as needed
        }
    }

    // Simplified check to see if data contains an allowed website
    private boolean isAllowed(String data) {
        return data.contains("youtube.com") || data.contains("mail.google.com") ||
               data.contains("maps.google.com") || data.contains("whatsapp.com");
    }
}
